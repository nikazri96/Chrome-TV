# TV Browser (kursor guna remote)

Browser ringkas untuk Android TV / Google TV / TV box. Guna enjin Chromium (WebView) sistem,
dengan **kursor tetikus yang digerakkan terus pakai D-pad remote** dan **sistem tab** ala Chrome.

## Kawalan remote

| Butang | Fungsi |
|---|---|
| D-pad atas/bawah/kiri/kanan | Gerak kursor (tahan lama = makin laju, boleh serong) |
| OK / Enter | Klik di kedudukan kursor (kotak teks akan buka papan kekunci) |
| Tekan lama OK (~1 saat) atau MENU / INFO | Buka menu |
| Kursor sampai tepi skrin | Skrol halaman |
| CH+ / CH- (atau Page Up/Down) | Skrol satu skrin |
| Media Next / Previous | Tukar ke tab seterusnya / sebelumnya |
| Back | Halaman sebelum > keluar skrin penuh video > tutup tab (kalau ada banyak tab) > keluar app |

## Menu

- Kotak URL / carian (tekan OK pada kotak, taip, Enter)
- **Tab**: `+ Tab baru`, `Tutup tab`, dan senarai tab (tab aktif bertanda ●). Pilih tab untuk tukar.
- Belakang, Depan, Muat semula, Laman utama
- **Laju - / Laju +**: laraskan kelajuan kursor 1-10
- Mod desktop ON/OFF, Keluar app

Link `target=_blank` / `window.open` yang ditekan pengguna akan terbuka dalam tab baru.
Popup tanpa klik (iklan) disekat. Link dari app lain pun dibuka dalam tab baru.

## Cara dapatkan APK

### Cara A: GitHub Actions (tak perlu pasang apa-apa)
1. Buat repo GitHub baru, upload semua fail dalam folder ini (termasuk `.github`).
2. Buka tab **Actions** > **Build APK** > tunggu siap (3-5 minit).
3. Muat turun artifact `tv-browser-apk` > dalamnya ada `app-debug.apk`.

### Cara B: Android Studio
1. File > Open > pilih folder `TVBrowser`.
2. Biar Gradle sync, kemudian **Build > Build APK(s)**.
3. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Pasang di TV
- **ADB**: `adb connect IP_TV:5555` kemudian `adb install app-debug.apk`
- Atau letak APK dalam pendrive / guna app "Send Files to TV", kemudian buka dengan File Manager di TV
  (perlu bagi kebenaran "Install unknown apps").

App akan muncul di launcher TV dengan nama **TV Browser**.

## Nota
- Ini bukan Google Chrome sebenar (Chrome tak boleh dibina semula), tapi guna enjin yang sama
  (Android System WebView). Pastikan "Android System WebView" di TV dikemas kini.
- Tapak yang perlukan Widevine DRM (Netflix dll.) mungkin tak boleh main.
- Tab tidak disimpan bila app ditutup (setiap kali buka, mula dengan satu tab).
