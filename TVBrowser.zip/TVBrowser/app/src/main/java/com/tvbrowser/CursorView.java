package com.tvbrowser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Overlay yang melukis anak panah kursor tetikus. */
public class CursorView extends View {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrow = new Path();
    private final float unit;
    private float x;
    private float y;
    private boolean pressed;

    public CursorView(Context c) {
        super(c);
        unit = c.getResources().getDisplayMetrics().density * 1.6f;
        setFocusable(false);
        setClickable(false);

        fill.setStyle(Paint.Style.FILL);
        stroke.setColor(Color.BLACK);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.4f);
        stroke.setStrokeJoin(Paint.Join.ROUND);

        arrow.moveTo(0, 0);
        arrow.lineTo(0, 17);
        arrow.lineTo(4, 13);
        arrow.lineTo(7, 20);
        arrow.lineTo(10, 18.5f);
        arrow.lineTo(7, 12);
        arrow.lineTo(12.5f, 12);
        arrow.close();
    }

    public void setPos(float nx, float ny) {
        x = nx;
        y = ny;
        invalidate();
    }

    /** Tukar warna sekejap bila klik. */
    public void flash() {
        pressed = true;
        invalidate();
        postDelayed(() -> {
            pressed = false;
            invalidate();
        }, 150);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        fill.setColor(pressed ? 0xFF8AB4F8 : Color.WHITE);
        canvas.save();
        canvas.translate(x, y);
        canvas.scale(unit, unit);
        canvas.drawPath(arrow, fill);
        canvas.drawPath(arrow, stroke);
        canvas.restore();
    }
}
