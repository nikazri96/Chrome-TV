package com.tvbrowser;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Browser untuk Android TV. Kursor tetikus digerakkan dengan D-pad,
 * OK = klik, tekan lama OK / MENU = buka menu (ada tab, URL, tetapan).
 */
public class MainActivity extends Activity {

    private static final String HOME = "https://www.google.com";
    private static final String UA_DESKTOP =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/124.0.0.0 Safari/537.36";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int MIN_SPEED = 1;
    private static final int MAX_SPEED = 10;

    private static class Tab {
        final WebView view;
        String title = "";

        Tab(WebView v) {
            view = v;
        }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<Tab> tabs = new ArrayList<>();

    private SharedPreferences prefs;
    private FrameLayout root;
    private WebView web; // tab yang sedang dipaparkan
    private CursorView cursor;
    private LinearLayout menu;
    private LinearLayout tabRow;
    private EditText urlBox;
    private TextView speedLabel;
    private Button desktopBtn;

    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;

    private int speed;
    private boolean desktop;
    private boolean menuOpen;

    private float cx;
    private float cy;
    private boolean up;
    private boolean down;
    private boolean left;
    private boolean right;
    private boolean loopRunning;
    private long holdStart;
    private long lastFrame;
    private boolean okLong;

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        prefs = getSharedPreferences("tvb", MODE_PRIVATE);
        speed = prefs.getInt("speed", 5);
        desktop = prefs.getBoolean("desktop", true);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        cursor = new CursorView(this);
        root.addView(cursor, new FrameLayout.LayoutParams(MATCH, MATCH));

        buildMenu();
        addTab(); // tab pertama (dimasukkan di bawah kursor)
        setContentView(root);
        hideSystemUi();

        root.post(() -> {
            cx = root.getWidth() / 2f;
            cy = root.getHeight() / 2f;
            cursor.setPos(cx, cy);
        });

        loadFromIntent(getIntent(), true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        loadFromIntent(intent, false);
    }

    @Override
    protected void onPause() {
        stopMove();
        for (Tab t : tabs) t.view.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (Tab t : tabs) t.view.onResume();
        hideSystemUi();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        root.removeAllViews();
        for (Tab t : tabs) t.view.destroy();
        tabs.clear();
        super.onDestroy();
    }

    private void loadFromIntent(Intent i, boolean first) {
        Uri d = i != null ? i.getData() : null;
        if (d != null) {
            if (first) web.loadUrl(d.toString());
            else addTab().loadUrl(d.toString()); // link dari app lain = tab baru
        } else if (first) {
            web.loadUrl(HOME);
        }
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    // ---------------------------------------------------------------- tabs

    private int currentIndex() {
        for (int i = 0; i < tabs.size(); i++) {
            if (tabs.get(i).view == web) return i;
        }
        return -1;
    }

    private Tab findTab(WebView v) {
        for (Tab t : tabs) {
            if (t.view == v) return t;
        }
        return null;
    }

    /** Cipta tab baru, paparkan, dan pulangkan WebView-nya. */
    private WebView addTab() {
        WebView wv = makeWebView();
        tabs.add(new Tab(wv));
        switchTo(tabs.size() - 1);
        return wv;
    }

    private void switchTo(int i) {
        if (i < 0 || i >= tabs.size()) return;
        hideCustomView();
        WebView next = tabs.get(i).view;
        if (web != null && web != next) root.removeView(web);
        web = next;
        if (web.getParent() == null) {
            root.addView(web, 0, new FrameLayout.LayoutParams(MATCH, MATCH));
        }
        web.setVisibility(View.VISIBLE);
        web.setFocusable(!menuOpen);
        if (!menuOpen) {
            web.setFocusableInTouchMode(true);
            web.requestFocus();
        }
        refreshTabs();
    }

    private void cycleTab(int delta) {
        int n = tabs.size();
        if (n < 2) return;
        switchTo((currentIndex() + delta + n) % n);
    }

    private void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        if (tabs.size() == 1) {
            web.loadUrl(HOME); // tab terakhir: kosongkan, jangan tutup app
            return;
        }
        Tab t = tabs.remove(i);
        boolean wasCurrent = t.view == web;
        if (wasCurrent) {
            hideCustomView();
            root.removeView(web);
            web = null;
        }
        t.view.destroy();
        if (wasCurrent) {
            switchTo(Math.min(i, tabs.size() - 1));
        } else {
            refreshTabs();
        }
    }

    private void refreshTabs() {
        if (tabRow == null) return;
        int cur = currentIndex();
        boolean rebuild = tabRow.getChildCount() != tabs.size();
        if (rebuild) tabRow.removeAllViews();

        for (int i = 0; i < tabs.size(); i++) {
            Button b;
            if (rebuild) {
                final int idx = i;
                b = new Button(this);
                b.setAllCaps(false);
                b.setOnClickListener(v -> {
                    switchTo(idx);
                    closeMenu();
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
                lp.leftMargin = dpi(4);
                lp.rightMargin = dpi(4);
                tabRow.addView(b, lp);
            } else {
                b = (Button) tabRow.getChildAt(i);
            }
            String title = tabs.get(i).title;
            if (title == null || title.isEmpty()) title = "Tab baru";
            if (title.length() > 18) title = title.substring(0, 17) + "…";
            b.setText((i == cur ? "● " : "") + (i + 1) + ". " + title);
            b.setTypeface(null, i == cur ? Typeface.BOLD : Typeface.NORMAL);
        }
        if (rebuild && menuOpen && getCurrentFocus() == null) urlBox.requestFocus();
    }

    // ---------------------------------------------------------------- webview

    private WebView makeWebView() {
        final WebView wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(desktop ? UA_DESKTOP : null);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(wv, true);

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String u = req.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, req.getUrl()));
                } catch (Exception ignored) {
                    // tiada app untuk skema ini
                }
                return true;
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCallback = cb;
                root.addView(view, 1, new FrameLayout.LayoutParams(MATCH, MATCH));
                web.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onHideCustomView() {
                hideCustomView();
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                Tab t = findTab(view);
                if (t != null) {
                    t.title = title;
                    refreshTabs();
                }
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog,
                                          boolean isUserGesture, Message resultMsg) {
                if (!isUserGesture) return false; // sekat popup iklan
                WebView nw = addTab();
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(nw);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public void onCloseWindow(final WebView window) {
                handler.post(() -> {
                    for (int i = 0; i < tabs.size(); i++) {
                        if (tabs.get(i).view == window) {
                            closeTab(i);
                            break;
                        }
                    }
                });
            }
        });
        return wv;
    }

    private void hideCustomView() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (web != null) web.setVisibility(View.VISIBLE);
        if (customCallback != null) {
            WebChromeClient.CustomViewCallback cb = customCallback;
            customCallback = null;
            cb.onCustomViewHidden();
        }
    }

    private void applyUserAgent() {
        // null = guna UA lalai sistem
        for (Tab t : tabs) {
            t.view.getSettings().setUserAgentString(desktop ? UA_DESKTOP : null);
        }
    }

    private void go(String input) {
        String s = input.trim();
        if (s.isEmpty()) return;
        String url;
        if (s.startsWith("http://") || s.startsWith("https://")) {
            url = s;
        } else if (s.contains(".") && !s.contains(" ")) {
            url = "https://" + s;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(s);
        }
        web.loadUrl(url);
    }

    // ---------------------------------------------------------------- menu

    private int dpi(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildMenu() {
        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setBackgroundColor(0xF0202124);
        int p = dpi(20);
        menu.setPadding(p, p, p, p);
        menu.setVisibility(View.GONE);

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setHint("Taip alamat web atau carian, kemudian tekan Enter");
        urlBox.setHintTextColor(0xFF9AA0A6);
        urlBox.setTextColor(Color.WHITE);
        urlBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setOnEditorActionListener((tv, actionId, ev) -> {
            go(tv.getText().toString());
            closeMenu();
            return true;
        });
        menu.addView(urlBox, new LinearLayout.LayoutParams(MATCH, WRAP));

        // baris tab: [+ Tab baru] [Tutup tab] [strip tab boleh skrol]
        LinearLayout tabBar = newRow();
        addBtn(tabBar, "+ Tab baru", v -> {
            WebView wv = addTab();
            wv.loadUrl(HOME);
            urlBox.setText("");
            urlBox.requestFocus();
        });
        addBtn(tabBar, "Tutup tab", v -> {
            closeTab(currentIndex());
            String u = web.getUrl();
            urlBox.setText(u == null ? "" : u);
        });
        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabScroll.addView(tabRow, new FrameLayout.LayoutParams(WRAP, WRAP));
        tabBar.addView(tabScroll, new LinearLayout.LayoutParams(0, WRAP, 4f));

        LinearLayout row1 = newRow();
        addBtn(row1, "Belakang", v -> {
            if (web.canGoBack()) web.goBack();
            closeMenu();
        });
        addBtn(row1, "Depan", v -> {
            if (web.canGoForward()) web.goForward();
            closeMenu();
        });
        addBtn(row1, "Muat semula", v -> {
            web.reload();
            closeMenu();
        });
        addBtn(row1, "Laman utama", v -> {
            web.loadUrl(HOME);
            closeMenu();
        });
        addBtn(row1, "Tutup menu", v -> closeMenu());

        LinearLayout row2 = newRow();
        speedLabel = new TextView(this);
        speedLabel.setTextColor(Color.WHITE);
        speedLabel.setTextSize(18);
        speedLabel.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1.4f);
        row2.addView(speedLabel, lp);
        addBtn(row2, "Laju -", v -> changeSpeed(-1));
        addBtn(row2, "Laju +", v -> changeSpeed(1));
        desktopBtn = addBtn(row2, "", v -> {
            desktop = !desktop;
            prefs.edit().putBoolean("desktop", desktop).apply();
            applyUserAgent();
            updateLabels();
            web.reload();
        });
        addBtn(row2, "Keluar app", v -> finish());

        root.addView(menu, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP));
        updateLabels();
    }

    private LinearLayout newRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dpi(10);
        menu.addView(row, lp);
        return row;
    }

    private Button addBtn(LinearLayout row, String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setFocusable(true);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp.leftMargin = dpi(4);
        lp.rightMargin = dpi(4);
        row.addView(b, lp);
        return b;
    }

    private void changeSpeed(int delta) {
        speed = Math.max(MIN_SPEED, Math.min(MAX_SPEED, speed + delta));
        prefs.edit().putInt("speed", speed).apply();
        updateLabels();
    }

    private void updateLabels() {
        speedLabel.setText("Kelajuan kursor: " + speed + " / " + MAX_SPEED);
        desktopBtn.setText("Mod desktop: " + (desktop ? "ON" : "OFF"));
    }

    private void openMenu() {
        if (menuOpen) return;
        stopMove();
        menuOpen = true;
        updateLabels();
        refreshTabs();
        String u = web.getUrl();
        urlBox.setText(u == null ? "" : u);
        menu.setVisibility(View.VISIBLE);
        cursor.setVisibility(View.INVISIBLE);
        web.setFocusable(false);
        urlBox.requestFocus();
    }

    private void closeMenu() {
        if (!menuOpen) return;
        menuOpen = false;
        menu.setVisibility(View.GONE);
        cursor.setVisibility(View.VISIBLE);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
    }

    // ---------------------------------------------------------------- remote keys

    private static boolean isOk(int k) {
        return k == KeyEvent.KEYCODE_DPAD_CENTER
                || k == KeyEvent.KEYCODE_ENTER
                || k == KeyEvent.KEYCODE_NUMPAD_ENTER
                || k == KeyEvent.KEYCODE_BUTTON_A;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        int a = e.getAction();

        if (menuOpen) {
            // buang OK yang masih ditekan selepas tekan-lama (elak keyboard terbuka sendiri)
            if (okLong && isOk(k)) {
                if (a == KeyEvent.ACTION_UP) okLong = false;
                return true;
            }
            if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_MENU) {
                if (a == KeyEvent.ACTION_UP) closeMenu();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                onDirection(k, e);
                return true;

            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                onOk(e);
                return true;

            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_SETTINGS:
                if (a == KeyEvent.ACTION_UP) openMenu();
                return true;

            case KeyEvent.KEYCODE_BACK:
                if (a == KeyEvent.ACTION_UP) {
                    if (customView != null) hideCustomView();
                    else if (web.canGoBack()) web.goBack();
                    else if (tabs.size() > 1) closeTab(currentIndex());
                    else finish();
                }
                return true;

            case KeyEvent.KEYCODE_MEDIA_NEXT:
                if (a == KeyEvent.ACTION_UP) cycleTab(1);
                return true;

            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                if (a == KeyEvent.ACTION_UP) cycleTab(-1);
                return true;

            case KeyEvent.KEYCODE_CHANNEL_UP:
            case KeyEvent.KEYCODE_PAGE_UP:
                if (a == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) web.pageUp(false);
                return true;

            case KeyEvent.KEYCODE_CHANNEL_DOWN:
            case KeyEvent.KEYCODE_PAGE_DOWN:
                if (a == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) web.pageDown(false);
                return true;

            default:
                return super.dispatchKeyEvent(e);
        }
    }

    // ---------------------------------------------------------------- cursor movement

    private void onDirection(int k, KeyEvent e) {
        boolean on;
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() > 0) return; // kita guna gelung sendiri, bukan key-repeat
            on = true;
        } else if (e.getAction() == KeyEvent.ACTION_UP) {
            on = false;
        } else {
            return;
        }

        boolean wasMoving = up || down || left || right;
        if (k == KeyEvent.KEYCODE_DPAD_UP) up = on;
        else if (k == KeyEvent.KEYCODE_DPAD_DOWN) down = on;
        else if (k == KeyEvent.KEYCODE_DPAD_LEFT) left = on;
        else right = on;
        boolean moving = up || down || left || right;

        long now = SystemClock.uptimeMillis();
        if (on) {
            // anjakan kecil supaya ketukan pantas tetap menggerakkan kursor
            float n = dpi(10);
            float dx = k == KeyEvent.KEYCODE_DPAD_RIGHT ? n : (k == KeyEvent.KEYCODE_DPAD_LEFT ? -n : 0);
            float dy = k == KeyEvent.KEYCODE_DPAD_DOWN ? n : (k == KeyEvent.KEYCODE_DPAD_UP ? -n : 0);
            moveCursor(dx, dy);
            if (!wasMoving) holdStart = now;
        }
        if (moving && !loopRunning) {
            loopRunning = true;
            lastFrame = now;
            handler.postDelayed(tick, 16);
        }
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (menuOpen || !(up || down || left || right)) {
                loopRunning = false;
                return;
            }
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(50, now - lastFrame) / 1000f;
            lastFrame = now;

            float held = (now - holdStart) / 1000f;
            float accel = 1f + Math.min(held, 1.2f) * 1.5f; // makin lama tahan, makin laju
            float dist = dpi(speed * 110f) * accel * dt;

            float dx = (right ? 1 : 0) - (left ? 1 : 0);
            float dy = (down ? 1 : 0) - (up ? 1 : 0);
            if (dx != 0 && dy != 0) dist *= 0.7071f;
            moveCursor(dx * dist, dy * dist);

            handler.postDelayed(this, 16);
        }
    };

    private void stopMove() {
        up = false;
        down = false;
        left = false;
        right = false;
        loopRunning = false;
        handler.removeCallbacks(tick);
    }

    private void moveCursor(float dx, float dy) {
        int w = root.getWidth();
        int h = root.getHeight();
        if (w == 0 || h == 0) return;

        float nx = cx + dx;
        float ny = cy + dy;
        int sx = 0;
        int sy = 0;
        if (nx < 0) {
            sx = (int) nx;
            nx = 0;
        } else if (nx > w - 1) {
            sx = (int) (nx - (w - 1));
            nx = w - 1;
        }
        if (ny < 0) {
            sy = (int) ny;
            ny = 0;
        } else if (ny > h - 1) {
            sy = (int) (ny - (h - 1));
            ny = h - 1;
        }
        cx = nx;
        cy = ny;
        cursor.setPos(cx, cy);

        // kursor sampai tepi skrin = skrol halaman
        if (customView == null && web != null && (sx != 0 || sy != 0)) web.scrollBy(sx, sy);
    }

    // ---------------------------------------------------------------- click

    private final Runnable longPress = () -> {
        okLong = true;
        openMenu();
    };

    private void onOk(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) {
                okLong = false;
                handler.postDelayed(longPress, 800);
            }
        } else if (e.getAction() == KeyEvent.ACTION_UP) {
            handler.removeCallbacks(longPress);
            if (!okLong) click(cx, cy);
            okLong = false;
        }
    }

    private void click(final float x, final float y) {
        final View target = customView != null ? customView : web;
        final long t = SystemClock.uptimeMillis();

        MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        d.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        target.dispatchTouchEvent(d);
        d.recycle();

        cursor.flash();

        handler.postDelayed(() -> {
            long t2 = SystemClock.uptimeMillis();
            MotionEvent u = MotionEvent.obtain(t, t2, MotionEvent.ACTION_UP, x, y, 0);
            u.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            target.dispatchTouchEvent(u);
            u.recycle();
            handler.postDelayed(this::maybeShowKeyboard, 250);
        }, 60);
    }

    /** Kalau yang diklik ialah kotak teks, paksa papan kekunci keluar. */
    private void maybeShowKeyboard() {
        if (customView != null || menuOpen || web == null) return;
        String js = "(function(){var e=document.activeElement;if(!e)return 0;"
                + "var t=(e.tagName||'').toLowerCase();"
                + "if(t==='textarea'||e.isContentEditable)return 1;"
                + "if(t!=='input')return 0;"
                + "var bad=['checkbox','radio','button','submit','reset','range','file','color','image'];"
                + "return bad.indexOf((e.type||'').toLowerCase())<0?1:0;})()";
        final WebView target = web;
        target.evaluateJavascript(js, value -> {
            if ("1".equals(value) && target == web) {
                web.requestFocus();
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }
}
